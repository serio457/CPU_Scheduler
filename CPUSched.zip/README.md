# For groupies

# this is how you use the git

for making your own branch, use:

git pull

git checkout -b "branch name // this creates a new branch, omit -b to not do that

you make your changes, then you:

git add .

git commit -m "<the commit message. basically, what did you do>"

git push // This puts what you did in your branch
